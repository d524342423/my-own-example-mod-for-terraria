using Terraria.ModLoader;

namespace Test
{
    public class Test : Mod
    {
        public static object NPCs { get; internal set; }
    }
}